# currently under implementation

pv = 10
pvString = 
batt = 10
hour = 1
resultsFolder = "../results/"
configFolder = resultsFolder*"pv"*number_to_padded_string(pv)*"_batt"*number_to_padded_string(batt)*"/"


